#include <stdio.h>

int main()
{
    char ch[20] = " this is a string";
    printf("%d", ch);
    return 0;
}