#include <bits/stdc++.h>
//TO PRINT GREETINGS AGAINST YOUR NAME!!
using namespace std;
int main()
{
    char n[20];
    cout << "enter your name";
    cin >> n;
    cout << endl;
    cout << "Good Moring " << n << endl;

    return 0;
}